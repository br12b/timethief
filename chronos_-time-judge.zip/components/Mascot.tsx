import React from 'react';
import { MascotMood } from '../types';

interface MascotProps {
  mood: MascotMood;
  className?: string;
}

const Mascot: React.FC<MascotProps> = ({ mood, className = "" }) => {
  
  // Inline styles for specific mascot animations
  const animationStyles = `
    @keyframes blink {
      0%, 48%, 52%, 100% { transform: scaleY(1); }
      50% { transform: scaleY(0.1); }
    }
    @keyframes angry-shake {
      0%, 100% { transform: translateY(0) rotate(0); }
      25% { transform: translateY(1px) rotate(-3deg); }
      75% { transform: translateY(-1px) rotate(3deg); }
    }
    @keyframes happy-bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-3px); }
    }
    @keyframes disappointed-sigh {
      0%, 100% { transform: translateY(0) scaleX(1); }
      50% { transform: translateY(2px) scaleX(0.95); }
    }
    @keyframes sleepy-breath {
      0%, 100% { transform: scale(1); opacity: 0.8; }
      50% { transform: scale(1.05); opacity: 1; }
    }
    
    .eye-blink {
      transform-origin: center;
      transform-box: fill-box;
      animation: blink 4s infinite;
    }
    .eyebrow-angry {
      transform-origin: center;
      transform-box: fill-box;
      animation: angry-shake 0.4s infinite;
    }
    .feature-happy {
      transform-origin: center;
      transform-box: fill-box;
      animation: happy-bounce 2s infinite ease-in-out;
    }
    .face-sigh {
      transform-origin: center;
      transform-box: fill-box;
      animation: disappointed-sigh 4s infinite ease-in-out;
    }
    .mouth-sleepy {
      transform-origin: center;
      transform-box: fill-box;
      animation: sleepy-breath 3s infinite ease-in-out;
    }
  `;

  // Eye shapes
  const renderEyes = () => {
    switch (mood) {
      case MascotMood.HAPPY:
        return (
          <g className="feature-happy">
            <path d="M70 90 Q85 105 100 90" stroke="currentColor" strokeWidth="6" fill="none" strokeLinecap="round" />
            <path d="M150 90 Q165 105 180 90" stroke="currentColor" strokeWidth="6" fill="none" strokeLinecap="round" />
          </g>
        );
      case MascotMood.ANGRY:
        return (
          <>
            <g className="eyebrow-angry">
               <path d="M65 85 L105 100" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
               <path d="M185 85 L145 100" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
            </g>
            <circle cx="85" cy="110" r="10" fill="currentColor" className="eye-blink" style={{ animationDelay: '0.2s' }} />
            <circle cx="165" cy="110" r="10" fill="currentColor" className="eye-blink" style={{ animationDelay: '0.3s' }} />
          </>
        );
      case MascotMood.SLEEPY:
        return (
          <>
            <path d="M70 110 L100 110" stroke="currentColor" strokeWidth="6" strokeLinecap="round" opacity="0.8" />
            <path d="M150 110 L180 110" stroke="currentColor" strokeWidth="6" strokeLinecap="round" opacity="0.8" />
            <text x="180" y="70" className="text-4xl font-bold animate-bounce" fill="currentColor" style={{ animationDuration: '3s' }}>Z</text>
            <text x="210" y="50" className="text-2xl font-bold animate-bounce delay-75" fill="currentColor" style={{ animationDuration: '3s', animationDelay: '1.5s' }}>z</text>
          </>
        );
      case MascotMood.DISAPPOINTED:
        return (
          <g className="face-sigh">
            <circle cx="85" cy="100" r="12" fill="currentColor" className="eye-blink" />
            <circle cx="165" cy="100" r="12" fill="currentColor" className="eye-blink" style={{ animationDelay: '0.1s' }} />
            <path d="M70 80 L100 85" stroke="currentColor" strokeWidth="4" strokeLinecap="round" opacity="0.6" />
            <path d="M180 80 L150 85" stroke="currentColor" strokeWidth="4" strokeLinecap="round" opacity="0.6" />
          </g>
        );
      case MascotMood.NEUTRAL:
      default:
        return (
          <>
            <circle cx="85" cy="100" r="12" fill="currentColor" className="eye-blink" />
            <circle cx="165" cy="100" r="12" fill="currentColor" className="eye-blink" style={{ animationDelay: '0.1s' }} />
          </>
        );
    }
  };

  // Mouth shapes
  const renderMouth = () => {
    switch (mood) {
      case MascotMood.HAPPY:
        return (
            <path d="M85 150 Q125 180 165 150" stroke="currentColor" strokeWidth="6" fill="none" strokeLinecap="round" 
                  className="feature-happy" style={{ animationDuration: '2.1s' }} />
        );
      case MascotMood.ANGRY:
        return (
            <path d="M85 170 Q125 150 165 170" stroke="currentColor" strokeWidth="6" fill="none" strokeLinecap="round" />
        );
      case MascotMood.DISAPPOINTED:
        return (
            <path d="M100 160 Q125 150 150 160" stroke="currentColor" strokeWidth="6" fill="none" strokeLinecap="round" 
                  className="face-sigh" />
        );
      case MascotMood.SLEEPY:
        return (
             <circle cx="125" cy="160" r="15" stroke="currentColor" strokeWidth="6" fill="none" 
                     className="mouth-sleepy" />
        );
      case MascotMood.NEUTRAL:
      default:
        return <path d="M90 160 L160 160" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />;
    }
  };

  const getColor = () => {
    switch (mood) {
      case MascotMood.ANGRY: return "text-red-500";
      case MascotMood.HAPPY: return "text-yellow-400";
      case MascotMood.SLEEPY: return "text-blue-300";
      case MascotMood.DISAPPOINTED: return "text-orange-400";
      default: return "text-sky-400";
    }
  };

  return (
    <div className={`relative ${className} ${getColor()} transition-colors duration-500`}>
      <style>{animationStyles}</style>
      <svg viewBox="0 0 250 250" className="w-full h-full drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
        {/* Outer Ring */}
        <circle cx="125" cy="125" r="110" stroke="currentColor" strokeWidth="8" fill="#1e293b" />
        
        {/* Hour Marks */}
        <g opacity="0.6">
            <line x1="125" y1="25" x2="125" y2="40" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
            <line x1="225" y1="125" x2="210" y2="125" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
            <line x1="125" y1="225" x2="125" y2="210" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
            <line x1="25" y1="125" x2="40" y2="125" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
        </g>

        {/* Dynamic Features */}
        {renderEyes()}
        {renderMouth()}
      </svg>
    </div>
  );
};

export default Mascot;