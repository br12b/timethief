import React, { useState } from 'react';
import { UserInput } from '../types';

interface InputFormProps {
  onSubmit: (data: UserInput) => void;
  isLoading: boolean;
  timeSpent: number;
  onTimeChange: (time: number) => void;
}

const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading, timeSpent, onTimeChange }) => {
  const [appCategory, setAppCategory] = useState('');
  const [userGoals, setUserGoals] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!appCategory || !timeSpent || !userGoals) return;
    
    onSubmit({
      appCategory,
      timeSpent,
      userGoals
    });
  };

  const formatTime = (minutes: number) => {
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hrs === 0) return `${mins}m`;
    return `${hrs}h ${mins}m`;
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md space-y-6 md:space-y-8 px-2">
      <div className="space-y-2">
        <label htmlFor="category" className="block text-sm font-medium text-slate-300 ml-1">
          What was the distraction?
        </label>
        <input
          id="category"
          type="text"
          placeholder="e.g. TikTok, League, Instagram"
          value={appCategory}
          onChange={(e) => setAppCategory(e.target.value)}
          // text-base prevents iOS zoom on focus
          className="w-full px-4 py-3.5 bg-slate-800 border border-slate-700 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none text-white text-base placeholder-slate-500 transition-all shadow-sm"
          disabled={isLoading}
          required
        />
      </div>

      <div className="space-y-4 bg-slate-800/30 p-4 rounded-xl border border-slate-700/30">
        <div className="flex justify-between items-end">
           <label htmlFor="time" className="block text-sm font-medium text-slate-300">
             Simulate Screen Time
           </label>
           <span className="text-sky-400 font-bold font-mono bg-sky-500/10 px-3 py-1 rounded text-lg">
             {formatTime(timeSpent)}
           </span>
        </div>
        
        <div className="py-2">
          <input
            id="time"
            type="range"
            min="0"
            max="600"
            step="15"
            value={timeSpent}
            onChange={(e) => onTimeChange(Number(e.target.value))}
            className="w-full transition-all touch-action-manipulation"
            style={{ height: '30px' }} // Taller touch target
            disabled={isLoading}
          />
        </div>
        
        <div className="flex justify-between text-xs text-slate-500 font-mono px-1">
           <span>0h</span>
           <span>5h</span>
           <span>10h</span>
        </div>
      </div>

      <div className="space-y-2">
        <label htmlFor="goals" className="block text-sm font-medium text-slate-300 ml-1">
          What *should* you be doing?
        </label>
        <input
          id="goals"
          type="text"
          placeholder="e.g. Learning Spanish, Gym, Startup"
          value={userGoals}
          onChange={(e) => setUserGoals(e.target.value)}
          // text-base prevents iOS zoom on focus
          className="w-full px-4 py-3.5 bg-slate-800 border border-slate-700 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none text-white text-base placeholder-slate-500 transition-all shadow-sm"
          disabled={isLoading}
          required
        />
      </div>

      <button
        type="submit"
        disabled={isLoading || timeSpent === 0}
        className={`w-full py-4 rounded-xl font-bold text-lg tracking-wide transition-all duration-300 active:scale-95
          ${isLoading || timeSpent === 0
            ? 'bg-slate-700 text-slate-400 cursor-not-allowed' 
            : 'bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white shadow-lg shadow-sky-500/25'
          }`}
      >
        {isLoading ? 'Summoning Chronos...' : 'JUDGE ME'}
      </button>
    </form>
  );
};

export default InputForm;