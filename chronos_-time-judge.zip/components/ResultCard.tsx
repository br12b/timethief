import React from 'react';
import { ChronosResponse } from '../types';

interface ResultCardProps {
  data: ChronosResponse;
  onReset: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ data, onReset }) => {
  return (
    <div className="w-full max-w-2xl animate-fade-in-up">
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl">
        
        {/* The Roast */}
        <div className="space-y-2 border-b border-slate-700 pb-6">
          <h3 className="text-sky-400 font-bold uppercase tracking-wider text-xs">The Verdict</h3>
          <p className="text-xl md:text-2xl font-light text-white leading-relaxed italic">
            "{data.roast}"
          </p>
        </div>

        {/* Opportunity Cost */}
        <div className="space-y-2 bg-slate-900/50 p-4 rounded-lg border border-slate-700/30">
          <h3 className="text-red-400 font-bold uppercase tracking-wider text-xs flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
            Lost Potential
          </h3>
          <p className="text-slate-200 font-medium">
            {data.opportunityCost}
          </p>
        </div>

        {/* Quick Recovery */}
        <div className="space-y-2">
          <h3 className="text-green-400 font-bold uppercase tracking-wider text-xs">Redemption Arc</h3>
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 flex items-start gap-3">
            <div className="mt-1 bg-green-500 rounded-full p-1">
              <svg className="w-4 h-4 text-slate-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <p className="text-green-100 font-medium">{data.quickRecovery}</p>
              <p className="text-green-500/60 text-xs mt-1">Takes less than 5 minutes.</p>
            </div>
          </div>
        </div>

        <button
          onClick={onReset}
          className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg font-medium transition-colors border border-slate-600 hover:border-slate-500"
        >
          Accept Judgment & Try Again
        </button>
      </div>
    </div>
  );
};

export default ResultCard;
