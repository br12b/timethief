import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ChronosResponse, MascotMood, UserInput } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    roast: {
      type: Type.STRING,
      description: "A witty, sarcastic, and slightly judgmental roast about the user's wasted time.",
    },
    opportunityCost: {
      type: Type.STRING,
      description: "A concrete calculation of what they could have achieved in their specific goals with that time.",
    },
    mood: {
      type: Type.STRING,
      enum: [
        MascotMood.HAPPY,
        MascotMood.NEUTRAL,
        MascotMood.SLEEPY,
        MascotMood.ANGRY,
        MascotMood.DISAPPOINTED
      ],
      description: "The emotional state of Chronos based on the severity of the wasted time.",
    },
    quickRecovery: {
      type: Type.STRING,
      description: "A specific, actionable 5-minute micro-habit to help them recover their productivity immediately.",
    },
  },
  required: ["roast", "opportunityCost", "mood", "quickRecovery"],
};

export const judgeMyTime = async (input: UserInput): Promise<ChronosResponse> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing.");
  }

  const prompt = `
    You are "Chronos", a sharp-witted and slightly sarcastic Time Management Specialist.
    Your goal is to convert wasted screen time into lost life opportunities.
    
    Input Data:
    - App Category: ${input.appCategory}
    - Time Spent: ${input.timeSpent} minutes
    - User Goals: ${input.userGoals}
    
    Task:
    1. Roast: Comment on the time spent with a witty, slightly judgmental tone.
    2. Opportunity Cost: Convert those minutes into specific progress in the user's goals.
    3. Determine Mood: HAPPY (rare, only if time < 10 mins), NEUTRAL (10-30 mins), DISAPPOINTED (30-60 mins), ANGRY (60-120 mins), SLEEPY (boring apps or > 120 mins).
    4. Action Plan: A 5-minute micro-habit.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        systemInstruction: "You are Chronos. You are sarcastic, intelligent, and obsessed with efficiency. You do not suffer fools gladely, but you genuinely want people to be better.",
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response from Chronos.");
    }

    const data = JSON.parse(text) as ChronosResponse;
    return data;
  } catch (error) {
    console.error("Chronos is currently unavailable:", error);
    throw error;
  }
};